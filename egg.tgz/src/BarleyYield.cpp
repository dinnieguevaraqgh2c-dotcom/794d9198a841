// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit response curve"); }
int main(){
  announce();
  return lionss_run_workload("BarleyYield");
}
