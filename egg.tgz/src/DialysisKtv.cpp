// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Compute Kt/V and URR\n", stdout);
  return lionss_run_workload("DialysisKtv");
}
