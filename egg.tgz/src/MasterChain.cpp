// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Limiter and loudness match"); }
int main(){
  announce();
  return lionss_run_workload("MasterChain");
}
