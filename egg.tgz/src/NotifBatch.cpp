// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Batch into digests per user"); }
int main(){
  announce();
  return lionss_run_workload("NotifBatch");
}
