// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Multi-agent path finding, 8 robots");
  std::fflush(stdout);
  return lionss_run_workload("amr-fleet");
}
