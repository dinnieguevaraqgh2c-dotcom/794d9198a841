// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("BC7 encode, quality 3\n", stdout);
  return lionss_run_workload("bc7_batch");
}
