// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Fuel with alternates and reserves\n", stdout);
  return lionss_run_workload("fuel-plan-rcss");
}
