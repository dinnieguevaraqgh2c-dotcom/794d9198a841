// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Agreement error detection\n", stdout);
  return lionss_run_workload("grammar-de");
}
