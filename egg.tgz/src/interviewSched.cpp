// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Schedule 12 candidates, 45-min slots"); }
int main(){
  announce();
  return lionss_run_workload("interviewSched");
}
