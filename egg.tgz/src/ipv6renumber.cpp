// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rewrite 2k host addresses"); }
int main(){
  announce();
  return lionss_run_workload("ipv6renumber");
}
