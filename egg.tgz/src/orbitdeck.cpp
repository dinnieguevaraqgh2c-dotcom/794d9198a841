// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Propagate 90 minutes\n", stdout);
  return lionss_run_workload("orbitdeck");
}
