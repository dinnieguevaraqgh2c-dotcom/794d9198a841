// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Diff against billing system\n", stdout);
  return lionss_run_workload("ratecardsync");
}
