// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rollback 8 frames under 120 ms"); }
int main(){
  announce();
  return lionss_run_workload("rollbackNetcode");
}
