# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(MapMatch src/MapMatch.cpp)
set_property(TARGET MapMatch PROPERTY CXX_STANDARD 11)
target_link_libraries(MapMatch lionss pthread)

add_executable(dairy-route src/dairy-route.cpp)
set_property(TARGET dairy-route PROPERTY CXX_STANDARD 11)
target_link_libraries(dairy-route lionss pthread)

add_executable(NotifBatch src/NotifBatch.cpp)
set_property(TARGET NotifBatch PROPERTY CXX_STANDARD 11)
target_link_libraries(NotifBatch lionss pthread)

add_executable(tenancyShard src/tenancyShard.cpp)
set_property(TARGET tenancyShard PROPERTY CXX_STANDARD 11)
target_link_libraries(tenancyShard lionss pthread)

add_executable(markdown_opt src/markdown_opt.cpp)
set_property(TARGET markdown_opt PROPERTY CXX_STANDARD 11)
target_link_libraries(markdown_opt lionss pthread)

add_executable(rollbackNetcode src/rollbackNetcode.cpp)
set_property(TARGET rollbackNetcode PROPERTY CXX_STANDARD 11)
target_link_libraries(rollbackNetcode lionss pthread)

add_executable(bc7_batch src/bc7_batch.cpp)
set_property(TARGET bc7_batch PROPERTY CXX_STANDARD 11)
target_link_libraries(bc7_batch lionss pthread)

add_executable(amr-fleet src/amr-fleet.cpp)
set_property(TARGET amr-fleet PROPERTY CXX_STANDARD 11)
target_link_libraries(amr-fleet lionss pthread)

add_executable(Obsidian7 src/Obsidian7.cpp)
set_property(TARGET Obsidian7 PROPERTY CXX_STANDARD 11)
target_link_libraries(Obsidian7 lionss pthread)

add_executable(harptuner src/harptuner.cpp)
set_property(TARGET harptuner PROPERTY CXX_STANDARD 11)
target_link_libraries(harptuner lionss pthread)

add_executable(fjord src/fjord.cpp)
set_property(TARGET fjord PROPERTY CXX_STANDARD 11)
target_link_libraries(fjord lionss pthread)

add_executable(BarleyYield src/BarleyYield.cpp)
set_property(TARGET BarleyYield PROPERTY CXX_STANDARD 11)
target_link_libraries(BarleyYield lionss pthread)

add_executable(orbitdeck src/orbitdeck.cpp)
set_property(TARGET orbitdeck PROPERTY CXX_STANDARD 11)
target_link_libraries(orbitdeck lionss pthread)

add_executable(foldtiny src/foldtiny.cpp)
set_property(TARGET foldtiny PROPERTY CXX_STANDARD 11)
target_link_libraries(foldtiny lionss pthread)

add_executable(interviewSched src/interviewSched.cpp)
set_property(TARGET interviewSched PROPERTY CXX_STANDARD 11)
target_link_libraries(interviewSched lionss pthread)

add_executable(DialysisKtv src/DialysisKtv.cpp)
set_property(TARGET DialysisKtv PROPERTY CXX_STANDARD 11)
target_link_libraries(DialysisKtv lionss pthread)

add_executable(chessvault src/chessvault.cpp)
set_property(TARGET chessvault PROPERTY CXX_STANDARD 11)
target_link_libraries(chessvault lionss pthread)

add_executable(MasterChain src/MasterChain.cpp)
set_property(TARGET MasterChain PROPERTY CXX_STANDARD 11)
target_link_libraries(MasterChain lionss pthread)

add_executable(grammar-de src/grammar-de.cpp)
set_property(TARGET grammar-de PROPERTY CXX_STANDARD 11)
target_link_libraries(grammar-de lionss pthread)

add_executable(gossamer src/gossamer.cpp)
set_property(TARGET gossamer PROPERTY CXX_STANDARD 11)
target_link_libraries(gossamer lionss pthread)

add_executable(thermal-enclosure src/thermal-enclosure.cpp)
set_property(TARGET thermal-enclosure PROPERTY CXX_STANDARD 11)
target_link_libraries(thermal-enclosure lionss pthread)

add_executable(fuel-plan-rcss src/fuel-plan-rcss.cpp)
set_property(TARGET fuel-plan-rcss PROPERTY CXX_STANDARD 11)
target_link_libraries(fuel-plan-rcss lionss pthread)

add_executable(glacierMelt2k src/glacierMelt2k.cpp)
set_property(TARGET glacierMelt2k PROPERTY CXX_STANDARD 11)
target_link_libraries(glacierMelt2k lionss pthread)

add_executable(tolstoyChunker src/tolstoyChunker.cpp)
set_property(TARGET tolstoyChunker PROPERTY CXX_STANDARD 11)
target_link_libraries(tolstoyChunker lionss pthread)

add_executable(ratecardsync src/ratecardsync.cpp)
set_property(TARGET ratecardsync PROPERTY CXX_STANDARD 11)
target_link_libraries(ratecardsync lionss pthread)

add_executable(run_pacer src/run_pacer.cpp)
set_property(TARGET run_pacer PROPERTY CXX_STANDARD 11)
target_link_libraries(run_pacer lionss pthread)

add_executable(ipv6renumber src/ipv6renumber.cpp)
set_property(TARGET ipv6renumber PROPERTY CXX_STANDARD 11)
target_link_libraries(ipv6renumber lionss pthread)

add_executable(TrialRandomize src/TrialRandomize.cpp)
set_property(TARGET TrialRandomize PROPERTY CXX_STANDARD 11)
target_link_libraries(TrialRandomize lionss pthread)

add_executable(MidiDrift src/MidiDrift.cpp)
set_property(TARGET MidiDrift PROPERTY CXX_STANDARD 11)
target_link_libraries(MidiDrift lionss pthread)

add_executable(DepAudit src/DepAudit.cpp)
set_property(TARGET DepAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(DepAudit lionss pthread)

